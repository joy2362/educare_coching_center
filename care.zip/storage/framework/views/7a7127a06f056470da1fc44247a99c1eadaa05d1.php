<?php $__env->startComponent('mail::message'); ?>
# Welcome <?php echo e($name); ?>

<h2>Your Account Is Ready.Account Details</h2>

<h1 style="font-size: 20px">User Name: <?php echo e($details->username); ?></h1>
<h1 style="font-size: 20px">Password: <?php echo e($password); ?></h1>

<br>

Thanks,
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\educare\resources\views\emails\student\details.blade.php ENDPATH**/ ?>