
<?php $__env->startSection('title'); ?>
    <title>Payment History</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid p-0">
            <h1 class="h3 mb-3"> Payment History
                <a href="<?php echo e(route('admin.student-account.create')); ?>" class="float-end btn btn-sm btn-success rounded mx-2" >Make new payment</a>
                <a href="<?php echo e(route('admin.student.credit.add')); ?>" class="float-end btn btn-sm btn-info rounded mx-2 " id="addCredit" >Add Debit</a>
            </h1>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <table class="table table-border" id="data">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Student id</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $debits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $debit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->index + 1); ?></td>
                                            <td><?php echo e($debit->student->username ?? ""); ?></td>
                                            <td><?php echo e($debit->amount ?? ""); ?></td>
                                            <td>
                                                <span class="badge <?php if($debit->status == "paid"): ?> badge-success <?php else: ?> badge-danger <?php endif; ?>"><?php echo e(ucfirst($debit->status)); ?></span>
                                            </td>
                                            <td><a href="<?php echo e(route('admin.student-account.show',$debit->id)); ?>" class="btn btn-sm btn-success rounded"><i class="align-middle" data-feather="eye"></i></a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            $(document).ready(function () {
                $('#data').DataTable();

                $(document).on("click", "#addCredit", function (e) {
                    e.preventDefault();
                    var link = $(this).attr("href");
                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, do it!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = link;
                        }
                    });
                });
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\php\laragon\www\educare\resources\views/admin/pages/student/account/index.blade.php ENDPATH**/ ?>