[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH E:\php\laragon\www\educare\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>