
<?php $__env->startSection('title'); ?>
    <title>Student</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid p-0">
            <h1 class="h3 mb-3">Payment Details
                <a href="<?php echo e(route('admin.student.payment.print',$debit->id)); ?>" class="float-end btn btn-sm btn-success rounded" ><i class="align-middle" data-feather="printer"></i></a>
            </h1>

            <div class="row mt-6">
                <div class="col-12">
                        <div class="d-flex justify-content-center">

                            <div class="col-md-8">
                                <div class="card mb-3">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <h6 class="mb-0">Roll</h6>
                                            </div>
                                            <div class="col-sm-9 text-secondary">
                                                <?php echo e($debit->student->username ?? "-"); ?>

                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <h6 class="mb-0">Full Name</h6>
                                            </div>
                                            <div class="col-sm-9 text-secondary">
                                                <?php echo e(ucfirst($debit->student->details->first_name ?? "-")); ?> <?php echo e($debit->student->details->last_name ?? "-"); ?>

                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <h6 class="mb-0">Class</h6>
                                            </div>
                                            <div class="col-sm-9 text-secondary">
                                                <?php echo e(ucfirst($debit->student->class->name ?? "-")); ?>

                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <h6 class="mb-0">Batch</h6>
                                            </div>
                                            <div class="col-sm-9 text-secondary">
                                                <?php echo e(ucfirst($debit->student->batch->name ?? "-")); ?>

                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <h6 class="mb-0">Amount </h6>
                                            </div>
                                            <div class="col-sm-9 text-secondary">
                                                <?php echo e($debit->amount); ?> BDT
                                            </div>
                                        </div>
                                        <hr>

                                        <div class="row">
                                            <div class="col-sm-3">
                                                <h6 class="mb-0">Status</h6>
                                            </div>
                                            <div class="col-sm-9 text-secondary">
                                                <span class="badge <?php if($debit->status == "paid"): ?> badge-success <?php else: ?> badge-danger <?php endif; ?>"><?php echo e(ucfirst($debit->status)); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\php\laragon\www\educare\resources\views/admin/pages/student/account/view.blade.php ENDPATH**/ ?>