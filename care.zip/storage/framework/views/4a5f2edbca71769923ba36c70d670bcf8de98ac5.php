<?php $__env->startSection('title'); ?>
    <title>Profile Setting</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid p-0">

            <div class="mb-3">
                <h1 class="h3 d-inline align-middle">Profile</h1>
            </div>
            <div class="row">
                <div class="col-md-5 col-xl-4">
                    <div class="card mb-3">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Two Step Verification</h5>
                        </div>

                        <div class="card-body text-center">
                            <?php if(!Auth::guard('admin')->user()->two_factor_secret): ?>
                                <h5 class="card-title mb-0">Currently Turn Off</h5>
                                <form action="<?php echo e(url('/admin/two-factor-authentication')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-primary btn-sm">Turn on</button>
                                </form>
                            <?php else: ?>
                                <h5 class="card-title mb-3 ">Use Any TOTP compatible mobile authentication application such as<a href="https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en&gl=US" target="_blank"> Google Authenticator</a></h5>
                                <?php echo Auth::user()->twoFactorQrCodeSvg(); ?>

                            <div class="mt-3">

                                <form action="<?php echo e(route('admin.two-factor.disable')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <a class="btn btn-primary btn-sm " href="<?php echo e(url('admin/profile/setting/recovery-codes')); ?>">View Recovery Code</a>
                                    <button class="btn btn-danger btn-sm" type="submit">Turn Off</button>
                                </form>
                            </div>
                            <?php endif; ?>
                        </div>
                        <hr class="my-0" />
                    </div>
                </div>

                <div class="col-md-7 col-xl-8">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Update Password</h5>
                        </div>
                        <div class="card-body h-100">

                            <div class="d-flex align-items-start">
                                <form class="flex-grow-1" method="POST" action="<?php echo e(route('admin.password.change')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <div class="form-group g-2">
                                        <label for="current_password">Current Password</label>
                                        <input type="password" class="form-control"  id="current_password" name="current_password" required>
                                        <?php $__errorArgs = ['current_password','updatePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group g-2">
                                        <label for="password">New Password</label>
                                        <input type="password" class="form-control"  id="password" name="password" required >
                                        <?php $__errorArgs = ['password','updatePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group g-2">
                                        <label for="password_confirmation">Confirm Password</label>
                                        <input type="password" class="form-control"  id="password_confirmation" name="password_confirmation" required >
                                    </div>
                                    <button type="submit" class="btn btn-sm btn-danger mt-1"> Update</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\educare\resources\views\admin\pages\profile_setting\index.blade.php ENDPATH**/ ?>