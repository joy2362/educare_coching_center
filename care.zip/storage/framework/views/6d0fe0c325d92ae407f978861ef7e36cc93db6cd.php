<nav id="sidebar" class="sidebar js-sidebar">
    <div class="sidebar-content js-simplebar">
        <a class="sidebar-brand" href="<?php echo e(route('home')); ?>">
            <span class="align-middle">Educare</span>
        </a>

        <ul class="sidebar-nav">

            <li class="sidebar-item active">
                <a class="sidebar-link" href=" <?php echo e(route('home')); ?>  ">
                    <i class="align-middle" data-feather="home"></i> <span class="align-middle">home</span>
                </a>
            </li>
        </ul>

    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\educare\resources\views\layout\partials\student\sidebar.blade.php ENDPATH**/ ?>