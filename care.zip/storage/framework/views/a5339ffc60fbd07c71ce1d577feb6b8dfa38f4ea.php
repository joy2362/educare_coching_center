<?php $__env->startSection('title'); ?>
    <title>Class</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid p-0">

            <h1 class="h3 mb-3">Class
                <a href="<?php echo e(route('admin.class.create')); ?>" class="float-end btn btn-sm btn-success rounded" >Add New</a>
            </h1>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-border" id="classes">
                                    <thead>
                                    <tr>
                                        <th>Sl no</th>
                                        <th>Name</th>
                                        <th>Admission Fee</th>
                                        <th>Monthly Fee</th>
                                        <th>Other Fee</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index +1); ?></td>
                                        <td><?php echo e($class->name); ?></td>
                                        <td><?php echo e($class->admission_fee); ?></td>
                                        <td><?php echo e($class->monthly_fee); ?></td>
                                        <td><?php echo e($class->other_fee); ?></td>
                                        <td> <span class="badge <?php if($class->status == "active"): ?> badge-success <?php else: ?> badge-danger <?php endif; ?>" ><?php echo e(ucfirst($class->status)); ?></span>
                                        </td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn " type="button" data-toggle="dropdown" aria-expanded="false">
                                                    <i class="align-middle" data-feather="more-vertical"></i>
                                                </button>
                                                <div class="dropdown-menu">
                                                    <a class="m-2 dropdown-item" href="<?php echo e(route('admin.class.edit',$class->id)); ?>">Edit</a>
                                                    <a class="m-2 dropdown-item" href="<?php echo e(route('admin.class.show',$class->id)); ?>">View</a>
                                                    <a class="m-2 dropdown-item" id="delete" href="<?php echo e(url('/admin/class/delete/'.$class->id)); ?>">Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            $(document).ready(function() {
                $('#classes').DataTable();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\php\laragon\www\educare\resources\views/admin/pages/class/index.blade.php ENDPATH**/ ?>