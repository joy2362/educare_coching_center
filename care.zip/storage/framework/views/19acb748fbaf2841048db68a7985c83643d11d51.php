<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-6 text-start">
                <p class="mb-0">
                   Develop with <span class="text-danger">&#9829;</span> by <a href="https://github.com/joy2362" target="_blank"> Abdullah Zahid</a>
                </p>
            </div>

        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\educare\resources\views/layout/partials/footer.blade.php ENDPATH**/ ?>