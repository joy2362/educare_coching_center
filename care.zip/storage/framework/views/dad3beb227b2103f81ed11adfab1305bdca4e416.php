
<?php $__env->startSection('title'); ?>
    <title>Notice</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid p-0">
            <h1 class="h3 mb-3 ">Notice</h1>
            <div class="row">
                <div class="col-12">
                    <form method="post" action="<?php echo e(route('admin.notice.student.store')); ?>" >
                        <?php echo csrf_field(); ?>
                        <div class="card ">
                            <div class="card-body ">
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-floating g-2 mb-3">
                                            <select class="form-select <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="class" aria-label="Class" name="class" >
                                                <option selected>....</option>
                                                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option  value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <label for="class">Class</label>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-floating g-2 mb-3 batch_class">
                                            <select class="form-select <?php $__errorArgs = ['batch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="batch" aria-label="batch" name="batch" >
                                                <option selected>....</option>
                                            </select>
                                            <label for="batch">Batch</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-floating g-2 mb-3">
                                    <textarea class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Message" id="permanent-address" name="message" style="height: 100px"><?php echo e(old('message')); ?></textarea>
                                    <label for="message">Message</label>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-outline-primary g-2 float-right">Send</button>
                    </form>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    document.addEventListener("DOMContentLoaded", function() {
    $(document).ready(function() {
    function ajaxsetup(){
    $.ajaxSetup({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
    });
    }


    $(document).on('change','#class',function(e){
    let id = e.target.value;
    ajaxsetup();
    $.ajax({
    type:'get',
    url:"/admin/batch/fetch/"+id,
    dataType:'json',
    success: function(response){
    if(response.status == 404){
    Swal.fire(
    'Error!',
    response.message,
    'error'
    )
    }
    else{
    let batches =  $('#batch').empty();
    $.each(response.batches,function(key,val){
    batches.append('<option value ="'+val.id+'">'+val.name + " - "+val.batch_start+ " - " + val.batch_end +'</option>');
    });

    }
    }
    })

    });
    });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\educare\resources\views/admin/pages/student/notice.blade.php ENDPATH**/ ?>