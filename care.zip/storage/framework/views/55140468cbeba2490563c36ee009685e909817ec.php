<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('layout.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    <div class="wrapper">
         <!-- sidebar start -->
        <?php if(Auth::guard('admin')->check()): ?>
            <?php echo $__env->make('layout.partials.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php if(Auth::guard('web')->check()): ?>
            <?php echo $__env->make('layout.partials.student.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <!-- sidebar end -->
        <div class="main">
        <!-- top navbar start -->
        <?php if(Auth::guard('admin')->check()): ?>
            <?php echo $__env->make('layout.partials.admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php if(Auth::guard('web')->check()): ?>
            <?php echo $__env->make('layout.partials.student.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <!-- top navbar end -->
        <!-- main conten start-0 -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- main content end -->
        <!-- footer start-0 -->
        <?php echo $__env->make('layout.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- footer end- -->
        </div>
    </div>

    <?php echo $__env->make('layout.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('script'); ?>

</body>
</html>
<?php /**PATH E:\php\laragon\www\educare\resources\views/layout/master.blade.php ENDPATH**/ ?>