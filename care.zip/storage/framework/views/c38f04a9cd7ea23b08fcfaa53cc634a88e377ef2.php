
<?php $__env->startSection('title'); ?>
    <title>Exam Date</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid p-0">

            <h1 class="h3 mb-3">Exam  <a href="<?php echo e(route('admin.exam.index')); ?>" class=" btn btn-sm btn-info">Go Back</a>
            </h1>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">

                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-border" id="routine">
                                    <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Subject</th>
                                        <th>Total Mark</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $batch->exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($row->id); ?></td>
                                            <td><?php echo e($row->subject->name); ?></td>
                                            <td><?php echo e($row->total_mark); ?></td>
                                            <td><?php echo e(date('g:i a', strtotime($row->exam_date))); ?></td>
                                            <td>
                                                <?php if($row->result_published == 'no'): ?>
                                                    <a class="m-2 btn btn-sm btn-primary"  href="<?php echo e(url('/admin/exam/result/create/'.$row->id)); ?>">Published Result</a>
                                                <?php else: ?>
                                                    <a class="m-2 btn btn-sm btn-primary"  href="<?php echo e(url('/admin/exam/result/'.$row->id)); ?>">View Result</a>
                                                <?php endif; ?>

                                                <a class="m-2 btn btn-sm btn-danger" id="delete" href="<?php echo e(url('/admin/exam/delete/'.$row->id)); ?>"><i class="align-middle" data-feather="trash-2"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            $(document).ready(function() {
                $('#routine').DataTable();
            });
        });
    </script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            $(document).ready(function() {

                function ajax_setup(){
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                }

                $(document).on('click','.edit_button',function(e){
                    e.preventDefault();
                    let id = $(this).val();

                    ajax_setup();
                    $.ajax({
                        type:'get',
                        url:"/admin/routine/show/"+id,
                        dataType:'json',
                        success: function(response){
                            if(response.status === 404){
                                Swal.fire(
                                    'Error!',
                                    response.message,
                                    'error'
                                )
                            }
                            else{
                                $('#edit_id').val(response.routine.id);
                                $('#edit_subject').val(response.routine.subject);
                                $('#edit_start').val(response.routine.class_start);
                                $('#edit_teacher_initial').val(response.routine.teacher_initial);
                                $('#edit_end').val(response.routine.class_end);
                                $('#edit_day').val(response.days);
                                $('#edit_routine').modal('show');
                            }
                        }
                    })
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\php\laragon\www\educare\resources\views/admin/pages/exam/show.blade.php ENDPATH**/ ?>