<?php $__env->startSection('title'); ?>
    <title>Profile Setting</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid p-0">

            <div class="mb-3">
                <h1 class="h3 d-inline align-middle">Profile</h1>
            </div>
            <div class="row">
                <div class="col-md-5 col-xl-4">
                    <div class="card mb-3">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Two Step Verification Recovery Codes</h5>
                        </div>
                    </div>
                </div>
                <div class="card-body text-center">
                    <h5 class="card-title mb-3">Please do not Share Those Recovery code with anyone</h5>

                    <?php $__currentLoopData = json_decode(decrypt(auth()->user()->two_factor_recovery_codes)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="mb-3"><?php echo e($code); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\educare\resources\views\admin\pages\profile_setting\recovery.blade.php ENDPATH**/ ?>