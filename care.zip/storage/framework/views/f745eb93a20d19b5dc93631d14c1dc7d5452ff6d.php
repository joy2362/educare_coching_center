
<?php $__env->startSection('title'); ?>
    <title>Payment History</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid p-0">
            <h1 class="h3 mb-3">Student Payment History
                <a href="#" class="float-end btn btn-sm btn-success rounded" >Make new payment</a>
            </h1>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <table class="table table-border" id="data">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Student Name</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            $(document).ready(function() {
                $('#data').DataTable();
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\php\laragon\www\educare\resources\views/admin/pages/student_account/index.blade.php ENDPATH**/ ?>