
<?php $__env->startSection('title'); ?>
    <title>Exam Date</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid p-0">
            <h1 class="h3 mb-3"> Exam Date</h1>
            <div class="row">
                <div class="col-xl-12 col-xxl-12 d-flex">
                    <div class="w-100">
                        <div class="card">
                            <div class="card-header">
                            </div>
                            <div class="card-body">
                                <table class="table table-striped table-hover">
                                    <thead>
                                    <tr>
                                        <th class="text-center">Subject</th>
                                        <th class="text-center">Date</th>
                                        <th class="text-center">Total Mark</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $batch->exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($row->subject->name); ?></td>
                                            <td class="text-center"><?php echo e($row->exam_date); ?></td>
                                            <td class="text-center"><?php echo e($row->total_mark); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\educare\resources\views/student/pages/exam_date.blade.php ENDPATH**/ ?>