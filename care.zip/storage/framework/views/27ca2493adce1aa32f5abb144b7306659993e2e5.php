<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<script src="<?php echo e(asset('asset/js/app.js')); ?>"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.error("<?php echo e($error); ?>");
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    });
</script>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            <?php if(Session::has('status')): ?>
            Swal.fire({
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                title: 'Success!',
                text: '<?php echo e(Session::get('status')); ?>',
                icon: 'success',
                position:'top-end',
                toast:true
            })
            <?php endif; ?>
        <?php if(Session::has('messege')): ?>
        var type = "<?php echo e(Session::get('alert-type','info')); ?>"
        switch(type){
            case 'info':
                Swal.fire({
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    title: 'Info!',
                    text: '<?php echo e(Session::get('messege')); ?>',
                    icon: 'info',
                    position:'top-end',
                    toast:true
                })
                break;
            case 'success':
                Swal.fire({
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    title: 'Success!',
                    text: '<?php echo e(Session::get('messege')); ?>',
                    icon: 'success',
                    position:'top-end',
                    toast:true
                })
                break;
            case 'warning':
                Swal.fire({
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    title: 'Warning!',
                    text: '<?php echo e(Session::get('messege')); ?>',
                    icon: 'warning',
                    position:'top-end',
                    toast:true
                })
                break;
            case 'error':
                Swal.fire({
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    title: 'Error!',
                    text: '<?php echo e(Session::get('messege')); ?>',
                    icon: 'error',
                    position:'top-end',
                    toast:true
                })
                break;
        }
        <?php endif; ?>
        $(document).on("click", "#delete", function(e){
            e.preventDefault();
            var link = $(this).attr("href");
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = link;
                }
            })
            });
        });
    </script>


<?php /**PATH E:\php\laragon\www\educare\resources\views/layout/partials/script.blade.php ENDPATH**/ ?>