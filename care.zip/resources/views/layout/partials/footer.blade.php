<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-6 text-start">
                <p class="mb-0">
                   Develop with <span class="text-danger">&#9829;</span> by <a href="https://github.com/joy2362" target="_blank"> Abdullah Zahid</a>
                </p>
            </div>

             <div class="col-6 text-end">
                <p class="mb-0">
                   version &alpha; - 0.1.0
                </p>
            </div>

        </div>
    </div>
</footer>
