<?php

namespace App\Models;

use App\Models\System\BaseModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class routineDetail extends BaseModel
{
    use HasFactory;
}
