<?php

return [
    'username' => env('BULKSMS_USER_ID',''),
    'password' => env('BULKSMS_PASSWORD',''),
    'url' => env('BULKSMS_URL','')
];