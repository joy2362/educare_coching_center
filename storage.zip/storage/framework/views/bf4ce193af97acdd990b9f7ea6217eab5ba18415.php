<nav id="sidebar" class="sidebar js-sidebar">
    <div class="sidebar-content js-simplebar">
        <a class="sidebar-brand" href="<?php echo e(route('home')); ?>">
            <span class="align-middle"><img src="<?php echo e(asset('asset/img/icons/logo.png')); ?>" style="width: 40px;height: 40px" alt="logo"><span class="m-2">Educare</span>
</span>
        </a>

        <ul class="sidebar-nav">

            <li class="sidebar-item <?php echo e(request()->is('/')  ? 'active' :''); ?>">
                <a class="sidebar-link" href=" <?php echo e(route('home')); ?>  ">
                    <i class="align-middle" data-feather="home"></i> <span class="align-middle">Dashboard</span>
                </a>
            </li>
            <li class="sidebar-item <?php echo e(request()->is('exam-date')  ? 'active' :''); ?>">
                <a class="sidebar-link" href=" <?php echo e(route('exam-date')); ?>  ">
                    <i class="align-middle" data-feather="book-open"></i> <span class="align-middle">Exam Date</span>
                </a>
            </li>
            <li class="sidebar-item <?php echo e(request()->is('exam-result')  ? 'active' :''); ?>">
                <a class="sidebar-link" href=" <?php echo e(route('exam-result')); ?>  ">
                    <i class="align-middle" data-feather="gift"></i> <span class="align-middle">Result</span>
                </a>
            </li>
        </ul>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\educare\resources\views/layout/partials/student/sidebar.blade.php ENDPATH**/ ?>