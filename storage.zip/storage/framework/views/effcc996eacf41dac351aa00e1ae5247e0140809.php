
<?php $__env->startSection('title'); ?>
    <title>Result</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid p-0">
            <h1 class="h3 mb-3"> Result</h1>
            <div class="row">
                <div class="col-xl-12 col-xxl-12 d-flex">
                    <div class="w-100">
                        <div class="card">
                            <div class="card-header">
                            </div>
                            <div class="card-body">
                                <table class="table table-striped table-hover">
                                    <thead>
                                    <tr>
                                        <th class="text-center">Subject</th>
                                        <th class="text-center">Result</th>
                                        <th class="text-center">Total Mark</th>
                                        <th class="text-center">Attendance</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $user->results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <tr>
                                               <td class="text-center"><?php echo e($row->exam->subject->name); ?></td>
                                               <?php if(!$row->result): ?>
                                                   <td class="text-center">--</td>
                                               <?php else: ?>
                                                   <td class="text-center"><?php echo e($row->result); ?></td>
                                                   <?php endif; ?>
                                               <td class="text-center"><?php echo e($row->total_mark); ?></td>
                                               <td class="text-center"><?php echo e($row->attendance); ?></td>
                                           </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("script"); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\php\laragon\www\educare\resources\views/student/pages/result.blade.php ENDPATH**/ ?>