<?php $__env->startSection('title'); ?>
    <title>Student</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid p-0">
            <h1 class="h3 mb-3">Student
                <a href="<?php echo e(route('admin.student.create')); ?>" class="float-end btn btn-sm btn-success">Add New</a>
            </h1>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">

                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-border" id="student">
                                    <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Mobile</th>
                                        <th>Class</th>
                                        <th>Batch</th>
                                        <th>Division</th>
                                        <th>District</th>
                                        <th>Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($row->id); ?></td>
                                                <td><?php echo e($row->name); ?></td>
                                                <td><?php echo e($row->mobile_number); ?></td>
                                                <td><?php echo e($row->class); ?></td>
                                                <td><?php echo e($row->batch); ?></td>
                                                <td><?php echo e($row->division); ?></td>
                                                <td><?php echo e($row->district); ?></td>
                                                <td>Action</td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            $(document).ready(function() {
                $('#student').DataTable();
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\educare\resources\views\admin\pages\student\index.blade.php ENDPATH**/ ?>