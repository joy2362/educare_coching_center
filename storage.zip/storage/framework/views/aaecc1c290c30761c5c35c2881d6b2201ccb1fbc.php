<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Educare Coaching Center</title>
    <link rel="shortcut icon" href="<?php echo e(asset('asset/img/icons/icon_48x48.png')); ?>"/>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/toastr.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('asset/css/app.css')); ?>" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
    <style>
    <style>
    html, body { padding: 0; margin: 0; width: 100%; height: 100%; }
    * {box-sizing: border-box;}
    body { text-align: center; padding: 0; background: #d6433b; color: #fff; font-family: Open Sans; }
    h1 { font-size: 50px; font-weight: 100; text-align: center;}
    body { font-family: Open Sans; font-weight: 100; font-size: 20px; color: #fff; text-align: center; display: -webkit-box; display: -ms-flexbox; display: flex; -webkit-box-pack: center; -ms-flex-pack: center; justify-content: center; -webkit-box-align: center; -ms-flex-align: center; align-items: center;}
    article { display: block; width: 700px; padding: 50px; margin: 0 auto; }
    a { color: #fff; font-weight: bold;}
    a:hover { text-decoration: none; }
    svg { width: 75px; margin-top: 1em; }
</style>
</head>
<body>

<article>
    <h1>We&rsquo;ll be back soon!</h1>
    <div>
        <p>Sorry for the inconvenience. We&rsquo;re performing some maintenance at the moment. we&rsquo;ll be back up shortly!</p>
        <p>&mdash; Abdullah Zahid</p>
    </div>
</article>
</body>
</html><?php /**PATH C:\xampp\htdocs\educare\resources\views/admin/pages/maintaince_brake.blade.php ENDPATH**/ ?>