
<?php $__env->startSection('title'); ?>
    <title>Result</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid p-0">
            <h1 class="h3 mb-3 text-center">Result</h1>
            <div class="row">

                <div class="col">
                    <form method="post" action="<?php echo e(route('admin.result.store')); ?>" >
                        <?php echo csrf_field(); ?>
                            <?php $__currentLoopData = $batch->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row g-2 mb-3">
                                <div class="col-md">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="Id" readonly name="id[]" placeholder="id" value="<?php echo e($row->id); ?>">
                                        <label for="Id">Id</label>
                                    </div>
                                </div>
                                <div class="col-md">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="name" readonly placeholder="name" value="<?php echo e($row->name); ?>">
                                        <label for="name">Name</label>
                                    </div>
                                </div>
                                <input type="hidden" name="mobile[]" value="<?php echo e($row->parent_contact_number); ?>">
                                <div class="col-md">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="subject" placeholder="subject" readonly value="<?php echo e($exam->subject->name); ?>">
                                        <label for="subject">Subject</label>
                                    </div>
                                </div>
                                <div class="col-md">
                                    <div class="form-floating">
                                        <select class="form-select" id="attendance" aria-label="Attendance" name="attendance[]" required>
                                            <option selected value="present">Present</option>
                                            <option value="absent">Absent</option>
                                        </select>
                                        <label for="attendance">Attendance</label>
                                    </div>
                                </div>
                                <div class="col-md">
                                    <div class="form-floating">
                                        <input type="number" class="form-control" id="result" placeholder="result" name="result[]" max="<?php echo e($exam->total_mark); ?>">
                                        <label for="result">Result</label>
                                    </div>
                                </div>
                                <div class="col-md">
                                    <div class="form-floating">
                                        <input type="number" class="form-control" name="mark" id="mark" placeholder="mark" readonly value="<?php echo e($exam->total_mark); ?>">
                                        <label for="mark">Total Mark</label>
                                    </div>
                                </div>
                                <input type="hidden" value="<?php echo e($exam->id); ?>" name="exam_id">
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button type="submit" class="btn btn-success g-2 mt-3 float-right">Published</button>
                    </form>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\educare\resources\views/admin/pages/result/create.blade.php ENDPATH**/ ?>