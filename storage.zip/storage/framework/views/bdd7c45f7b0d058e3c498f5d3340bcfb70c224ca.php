
<?php $__env->startSection('title'); ?>
    <title>Student</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="container-fluid p-0">
            <h1 class="h3 mb-3">Add Payment</h1>

            <div class="row">
                <div class="col-12">
                    <?php if(empty($student)): ?>
                    <div class="card">
                        <div class="card-body">
                            <form class="row g-3" method="get" action="<?php echo e(route('admin.student-account.create')); ?>">

                                <div class="col-auto">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="username" name="username" placeholder="Student Username">
                                    </div>
                                </div>

                                <div class="col-auto">
                                    <button type="submit" class="btn btn-primary mb-3">Search</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php else: ?>
                        <div class="row gutters-sm">
                            <div class="col-md-4 mb-3">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex flex-column align-items-center text-center">
                                            <img src="<?php echo e($student->avatar ?? asset('asset/img/avatars/student/default.png')); ?>" alt="student" class="rounded-circle" width="150" height="150">
                                            <div class="mt-3">
                                                <h4><?php echo e(ucfirst($student->details->first_name)); ?> <?php echo e($student->details->last_name); ?></h4>
                                                <p class="text-secondary mb-1"><?php echo e($student->username); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card mt-3">
                                    <h5 class="fw-bold text-center">Recent payment history</h5>
                                    <ul class="list-group list-group-flush">
                                        <?php if(count($student->debit) >0): ?>
                                            <?php $__currentLoopData = $student->debit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $debit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                                    <h6 class="mb-0"><?php echo e($debit->amount); ?> BDT</h6>
                                                    <span class="text-secondary"><?php echo e($debit->created_at->diffForHumans()); ?></span>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <h5 class="fw-bold text-center">No previous payment recode found</h5>
                                        <?php endif; ?>

                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="card mb-3">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <h6 class="mb-0">Roll</h6>
                                            </div>
                                            <div class="col-sm-9 text-secondary">
                                                <?php echo e($student->username); ?>

                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <h6 class="mb-0">Full Name</h6>
                                            </div>
                                            <div class="col-sm-9 text-secondary">
                                                <?php echo e(ucfirst($student->details->first_name)); ?> <?php echo e($student->details->last_name); ?>

                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <h6 class="mb-0">Blood Group</h6>
                                            </div>
                                            <div class="col-sm-9 text-secondary">
                                                <?php echo e(ucfirst($student->details->blood_group) ?? "-"); ?>

                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <h6 class="mb-0">Mobile</h6>
                                            </div>
                                            <div class="col-sm-9 text-secondary">
                                                <?php echo e($student->details->contact_number ?? $student->details->parent_contact_number); ?>

                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <h6 class="mb-0">Address</h6>
                                            </div>
                                            <div class="col-sm-9 text-secondary">
                                                <?php echo e($student->details->permanent_address); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <form method="post" action="<?php echo e(route('admin.student-account.store')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="row gutters-sm">
                                        <div class="col-sm-6 mb-3">
                                            <div class="card h-100">
                                                <div class="card-body">
                                                    <h4 class="d-flex align-items-center mb-3 fw-bold">Pending Credits</h4>
                                                    <?php if(count($student->credit) > 0): ?>
                                                        <?php
                                                          $amount = 0;
                                                        ?>
                                                    <?php $__currentLoopData = $student->credit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                        $amount += $credit->amount;
                                                        ?>
                                                        <input type="hidden" name="id" value="<?php echo e($student->id); ?>">
                                                        <div class="form-group">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" checked type="checkbox" id="credit_<?php echo e($credit->id); ?>" name="credit[]" value="<?php echo e($credit->id); ?>">
                                                                <label class="form-check-label" for="credit_<?php echo e($credit->id); ?>"><?php echo e(ucfirst($credit->type) . " (".$credit->amount . ")"); ?></label>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <h5 class="fw-bold">No Pending credit found!!!</h5>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-6 mb-3">
                                            <div class="card h-100">
                                                <div class="card-body">
                                                    <h4 class="d-flex align-items-center mb-3 fw-bold">Payment</h4>
                                                    <div class="form-group">
                                                        <label for="amount">Amount</label>
                                                        <input type="text" class="form-control" id="amount" name="amount" value="<?php echo e($amount ?? 0); ?>">
                                                    </div>
                                                    <div class="form-group float-end">
                                                        <button type="submit" class="btn btn-success">Save</button>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {

        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>

        .card {
            box-shadow: 0 1px 3px 0 rgba(0,0,0,.1), 0 1px 2px 0 rgba(0,0,0,.06);
        }

        .card {
            position: relative;
            display: flex;
            flex-direction: column;
            min-width: 0;
            word-wrap: break-word;
            background-color: #fff;
            background-clip: border-box;
            border: 0 solid rgba(0,0,0,.125);
            border-radius: .25rem;
        }

        .card-body {
            flex: 1 1 auto;
            min-height: 1px;
            padding: 1rem;
        }

        .gutters-sm {
            margin-right: -8px;
            margin-left: -8px;
        }

        .gutters-sm>.col, .gutters-sm>[class*=col-] {
            padding-right: 8px;
            padding-left: 8px;
        }



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\php\laragon\www\educare\resources\views/admin/pages/student/account/create.blade.php ENDPATH**/ ?>